"use client";

export default function PricingPage() {
  return (
    <div className="container max-w-3xl py-12">
  <h1 className="text-3xl font-bold mb-4">Premium purchases are paused</h1>
  <p className="text-muted-foreground">If your account already has premium enabled, you still get the features. New purchases are disabled for now.</p>
    </div>
  );
}
