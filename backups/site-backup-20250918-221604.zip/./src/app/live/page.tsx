export default function LivePage() {
	return null;
}
