export default function LiveSessionPage() {
	return null;
}
