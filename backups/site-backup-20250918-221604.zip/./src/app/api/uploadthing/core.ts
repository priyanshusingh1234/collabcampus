export const fileRouter = {} as const;
export type AppFileRouter = typeof fileRouter;
