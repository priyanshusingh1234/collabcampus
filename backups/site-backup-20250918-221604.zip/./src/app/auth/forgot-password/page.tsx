"use client";

import ForgotPasswordForm from "@/components/auth/ForgotPasswordForm";

export default function ForgotPasswordPage() {
  return (
    <div className="container max-w-lg py-10">
      <ForgotPasswordForm />
    </div>
  );
}
