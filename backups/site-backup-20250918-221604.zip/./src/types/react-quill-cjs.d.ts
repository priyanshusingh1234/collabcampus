declare module 'react-quill/dist/react-quill' {
  const ReactQuill: any;
  export default ReactQuill;
}
